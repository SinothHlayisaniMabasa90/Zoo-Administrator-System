/*=============================================================
FileName: Insert Data into the Tables.sql
Programmer: Sinoth Hlayisani Mabasa
Description: This file will insert data sample into the database.
=============================================================*/

USE ZooRegister
GO

--insert data into Animal Table
INSERT INTO Animals(animalID, animalName, descriptions, speciesID)
VALUES	(1001,'Lion', '', 2001),
		(1002,'Giraffe', '', 2002),
		(1003,'Cheetah', '', 2003),
		(1004,'Tiger', '', 2004),
		(1005,'Hippo', '', 2005)

GO

--insert data into Species Table
INSERT INTO Species
VALUES	(2001, 'Panthera Leo'),
		(2002, 'Giraffids'),
		(2003, 'Acinonyx Jubatus'),
		(2004, 'Panthera tigris'),
		(2005, 'Hippopotamus amphibius')

GO

--inserting data into Users Table
INSERT INTO Users
VALUES	(50123, 'Sinoth', 'Mabasa@01'),
		(50124, 'Lebo', 'Tabane@01'),
		(50125, 'Leslie', 'Kleinbooi@01'),
		(50126, 'Brian', 'Ngobeni@01'),
		(50127, 'Thokozani', 'Mthembu@01')

GO




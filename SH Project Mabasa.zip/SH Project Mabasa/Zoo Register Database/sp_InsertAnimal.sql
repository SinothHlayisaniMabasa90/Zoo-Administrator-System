USE ZooRegister
GO

SET ANSI_NULLS ON  
GO  
SET QUOTED_IDENTIFIER ON  
GO  
-- =============================================
-- Author:		<Sinoth Hlayisani Mabasa>
-- Create date: <2021-09-21,,>
-- Description:	<InsertAnimalTable,,>
-- =============================================
CREATE PROCEDURE sp_InsertAnimal 
@animalID INT,  
@animalName VARCHAR(50),  
@descriptions VARCHAR(500),
@speciesID INT
  
AS  
BEGIN  
    -- SET NOCOUNT ON added to prevent extra result sets from  
    -- interfering with SELECT statements.  
    SET NOCOUNT ON;
  
    INSERT INTO Animals(animalID,animalName,descriptions, speciesID)   
           VALUES (@animalID,@animalName, @Descriptions, @speciesID)  
  
END  
GO 
USE ZooRegister
GO

SET ANSI_NULLS ON  
GO  
SET QUOTED_IDENTIFIER ON  
GO  
-- =============================================
-- Author:		<Sinoth Hlayisani Mabasa>
-- Create date: <2021-09-21,,>
-- Description:	<Delete Data into Animal Table,,>
-- =============================================
CREATE PROCEDURE sp_DeleteAnimalByAnimalID   
    @animalID INT  
AS  
BEGIN  
    -- SET NOCOUNT ON added to prevent extra result sets from  
    -- interfering with SELECT statements.  
    SET NOCOUNT ON; 
  
    DELETE FROM Animals  
    WHERE animalID = @animalID  
      
END  
GO  
USE ZooRegister
GO

SET ANSI_NULLS ON  
GO  
SET QUOTED_IDENTIFIER ON  
GO  
-- =============================================
-- Author:		<Sinoth Hlayisani Mabasa>
-- Create date: <2021-09-21,,>
-- Description:	<InsertSpeciesTable,,>
-- =============================================
CREATE PROCEDURE sp_InsertSpecies 
@speciesID INT,  
@speciesName VARCHAR(50)
  
AS  
BEGIN  
    -- SET NOCOUNT ON added to prevent extra result sets from  
    -- interfering with SELECT statements.  
    SET NOCOUNT ON; 
  
    INSERT INTO Species(speciesID,speciesName)   
           VALUES (@speciesID,@speciesName)  
  
END  
GO 
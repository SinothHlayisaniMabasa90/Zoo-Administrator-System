/*================================================================
File Name: Create Tables
Programmer: Sinoth Hlayisani Mabasa
Description: This will create a Tables and its constraints
==================================================================*/

USE ZooRegister
GO

--create table for Species
CREATE TABLE Species
(
	speciesID INT NOT NULL PRIMARY KEY,--input species category as PK
	speciesName VARCHAR(50) NOT NULL
)
GO

--create Animals table
CREATE TABLE Animals
(
	animalID INT NOT NULL PRIMARY KEY, --input animalID as PK
	animalName VARCHAR(50) NOT NULL,
	descriptions VARCHAR(500) NOT NULL,
	speciesID INT FOREIGN KEY REFERENCES Species(speciesID)--references FOREIGN KEY
)
GO

--create Users table
CREATE TABLE Users
(
	userID INT NOT NULL PRIMARY KEY,--set userID as PK
	userName VARCHAR(50) NOT NULL,
	password VARCHAR(50) NOT NULL,
)
GO
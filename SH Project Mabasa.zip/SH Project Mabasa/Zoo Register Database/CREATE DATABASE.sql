/*================================================================
File Name: Create Database
Programmer: Sinoth Hlayisani Mabasa
Description: This will create a database
==================================================================*/


USE master
GO

CREATE DATABASE ZooRegister
ON PRIMARY
(
	NAME = 'ZooRegister_data',
	FILENAME = 'C:\Zoo Register\ZooRegister_data.mdf',
	SIZE = 20MB,
	FILEGROWTH = 10%
)
LOG ON
(
	NAME = 'ZooRegister_log',
	FILENAME = 'C:\Zoo Register\ZooRegister_log.ldf',
	SIZE = 20MB,
	FILEGROWTH = 10%
)
GO

